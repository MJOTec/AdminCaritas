//
//  AdminCaritasApp.swift
//  AdminCaritas
//
//  Created by Alumno on 07/11/23.
//

import SwiftUI

@main
struct AdminCaritasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

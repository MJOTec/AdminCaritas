//
//  Recibos_Pendientes_Lista.swift
//  AdminCaritas
//
//  Created by Alumno on 07/11/23.
//

import SwiftUI

struct Recibos_Pendientes_Lista: View {
    @State var recibo: Recibos
    
    var body: some View {
        VStack{
            ZStack{
                if (recibo.Estatus == "Pendiente"){
                    Tarjeta_Nombre_Amarilla()
                }
                VStack{
                    Text("\(recibo.NombreDonante) \(recibo.ApellidoPaterno) ")
                        .font(.title2)
                        .bold()
                        .frame(width: 310, height: 28, alignment: .leading)
                    Text("\(recibo.Estatus)")
                        .fontWeight(.semibold)
                        .foregroundColor(Color.gray)
                        .frame(width: 250, alignment: .leading)
                }
            }
        }
    }
}

struct Recibos_Pendientes_Lista_Previews: PreviewProvider {
    static var previews: some View {
        var rec1: Recibos = listaRecibos[0]
        Recibos_Pendientes_Lista(recibo: rec1)
    }
}

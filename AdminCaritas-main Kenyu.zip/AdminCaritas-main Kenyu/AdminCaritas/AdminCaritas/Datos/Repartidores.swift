//
//  Repartidores.swift
//  Reto
//
//  Created by Jimena Gallegos on 13/10/23.
//

import Foundation

struct Repartidores: Identifiable{
    var id: Int
    var nombre: String
    var apellidos: String
    var estado: String
}
